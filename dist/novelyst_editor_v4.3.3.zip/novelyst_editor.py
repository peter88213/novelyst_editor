"""A multi-scene "plain text" editor plugin for novelyst.

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_editor
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
import sys
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
import locale
import gettext

# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_editor', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Scene Editor')
PLUGIN = f'{APPLICATION} plugin v4.3.3'
ICON = 'eLogo32'

__all__ = ['APPLICATION', 'PLUGIN', 'ICON', '_']
import webbrowser
from tkinter import ttk
from tkinter import messagebox
import re
from tkinter import ttk

#--- Regular expressions for counting words and characters like in LibreOffice.
# See: https://help.libreoffice.org/latest/en-GB/text/swriter/guide/words_count.html

ADDITIONAL_WORD_LIMITS = re.compile('--|—|–')
# this is to be replaced by spaces, thus making dashes and dash replacements word limits

NO_WORD_LIMITS = re.compile('\[.+?\]|\/\*.+?\*\/|-|^\>', re.MULTILINE)
# this is to be replaced by empty strings, thus excluding markup and comments from
# word counting, and making hyphens join words


class TextBox(tk.Text):
    """A text editor widget for yWriter raw markup.
    
    Public methods:
    get_text -- Return the whole text from the editor box.
    set_text(text) -- Put text into the editor box and clear the undo/redo stack.
    count_words -- Return the word count.
    italic -- Make the selection italic, or begin with italic input.
    bold -- Make the selection bold, or begin with bold input.
    plain -- Remove formatting from the selection.
    """
    _YW_TAGS = ('i', 'b')
    # Supported tags.

    def __init__(self, master=None, **kw):
        """Copied from tkinter.scrolledtext and modified (use ttk widgets).
        
        Extends the supeclass constructor.
        """
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side=tk.RIGHT, fill=tk.Y)

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.vbar['command'] = self.yview

        # Copy geometry methods of self.frame without overriding Text
        # methods -- hack!
        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def get_text(self, start='1.0', end=tk.END):
        """Return the whole text from the editor box."""
        text = self.get(start, end).strip(' \n')
        return text

    def set_text(self, text):
        """Put text into the editor box and clear the undo/redo stack."""
        self.insert(tk.END, text)
        self.edit_reset()
        # this is to prevent the user from clearing the box with Ctrl-Z

    def count_words(self):
        """Return the word count."""
        text = ADDITIONAL_WORD_LIMITS.sub(' ', self.get('1.0', tk.END))
        text = NO_WORD_LIMITS.sub('', text)
        return len(text.split())

    def italic(self, event=None):
        """Make the selection italic, or begin with italic input."""
        self._set_format(tag='i')

    def bold(self, event=None):
        """Make the selection bold, or begin with bold input."""
        self._set_format(tag='b')

    def plain(self, event=None):
        """Remove formatting from the selection."""
        self._set_format()

    def _set_format(self, event=None, tag=''):
        """Insert an opening/closing pair of yWriter markup tags."""
        if tag:
            # Toggle format as specified by tag.
            if self.tag_ranges(tk.SEL):
                text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
                if text.startswith(f'[{tag}]'):
                    if text.endswith(f'[/{tag}]'):
                        # The selection is already formatted: Remove markup.
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                # Format the selection: Add markup.
                text = self._remove_format(text, tag)
                # to make sure that there is no nested markup of the same type
                self._replace_selected(f'[{tag}]{text}[/{tag}]')
            else:
                # Add markup to the cursor position.
                self.insert(tk.INSERT, f'[{tag}]')
                endTag = f'[/{tag}]'
                self.insert(tk.INSERT, endTag)
                self.mark_set(tk.INSERT, f'{tk.INSERT}-{len(endTag)}c')
        elif self.tag_ranges(tk.SEL):
            # Remove all markup from the selection.
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            for tag in self._YW_TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)

    def _replace_selected(self, text):
        """Replace the selected passage by text; keep the selection."""
        self.mark_set(tk.INSERT, tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index(tk.INSERT)
        self.insert(tk.INSERT, text)
        selLast = self.index(tk.INSERT)
        self.tag_add(tk.SEL, selFirst, selLast)

    def _remove_format(self, text, tag):
        """Return text without opening/closing markup, if any."""
        if tag in self._YW_TAGS:
            finished = False
            while not finished:
                start = text.find(f'[{tag}]')
                if start >= 0:
                    end = text.find(f'[/{tag}]')
                    if  start < end:
                        text = f'{text[:start]}{text[start + 3:end]}{text[end + 4:]}'
                    else:
                        finished = True
                else:
                    finished = True
            return text

    def clear(self):
        self.delete('1.0', tk.END)

HELP_URL = 'https://peter88213.github.io/novelyst_editor/usage'
KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
KEY_APPLY_CHANGES = ('<Control-s>', 'Ctrl-S')
KEY_UPDATE_WORDCOUNT = ('<F5>', 'F5')
KEY_SPLIT_SCENE = ('<Control-Alt-s>', 'Ctrl-Alt-S')
KEY_ITALIC = ('<Control-i>', 'Ctrl-I')
KEY_BOLD = ('<Control-b>', 'Ctrl-B')
KEY_PLAIN = ('<Control-m>', 'Ctrl-M')

COLOR_MODES = [
        (_('Bright mode'), 'black', 'white'),
        (_('Light mode'), 'black', 'antique white'),
        (_('Dark mode'), 'light grey', 'gray20'),
        ]
# (name, foreground, background) tuples for color modes.


class SceneEditor(tk.Toplevel):
    """A separate scene editor window with a menu bar, a text box, and a status bar."""
    liveWordCount = False
    colorMode = 0

    def __init__(self, plugin, ui, scId, size, icon=None):
        self._ui = ui
        self._plugin = plugin
        self._scene = self._ui.novel.scenes[scId]
        self._scId = scId

        # Create an independent editor window.
        super().__init__()
        self.geometry(size)
        if icon:
            self.iconphoto(False, icon)

        # Add a main menu bar to the editor window.
        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        '''
        # Add a button bar to the editor window.
        self._buttonBar = tk.Frame(self)
        self._buttonBar.pack(expand=False, fill=tk.BOTH)
        '''

        # Add a text editor with scrollbar to the editor window.
        self._sceneEditor = TextBox(self,
                                    wrap='word',
                                    undo=True,
                                    autoseparators=True,
                                    spacing1=self._plugin.kwargs['paragraph_spacing'],
                                    spacing2=self._plugin.kwargs['line_spacing'],
                                    maxundo=-1,
                                    padx=self._plugin.kwargs['margin_x'],
                                    pady=self._plugin.kwargs['margin_y'],
                                    font=(self._plugin.kwargs['font_family'], self._plugin.kwargs['font_size']),
                                    )
        self._sceneEditor.pack(expand=True, fill=tk.BOTH)
        self._sceneEditor.pack_propagate(0)
        self._set_editor_colors()

        # Add a status bar to the editor window.
        self._statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self._statusBar.pack(expand=False, side=tk.LEFT)

        # Add navigation buttons to the bottom line.
        ttk.Button(self, text=_('Next'), command=self._load_next).pack(side=tk.RIGHT)
        ttk.Button(self, text=_('Previous'), command=self._load_prev).pack(side=tk.RIGHT)

        # Load the scene content into the text editor.
        self._load_scene()

        #--- Configure the user interface.
        '''
        # Add buttons to the button bar.
        tk.Button(self._buttonBar, text=_('Copy'), command=lambda: self._sceneEditor.event_generate("<<Copy>>")).pack(side=tk.LEFT)
        tk.Button(self._buttonBar, text=_('Cut'), command=lambda: self._sceneEditor.event_generate("<<Cut>>")).pack(side=tk.LEFT)
        tk.Button(self._buttonBar, text=_('Paste'), command=lambda: self._sceneEditor.event_generate("<<Paste>>")).pack(side=tk.LEFT)
        tk.Button(self._buttonBar, text=_('Italic'), command=self._sceneEditor.italic).pack(side=tk.LEFT)
        tk.Button(self._buttonBar, text=_('Bold'), command=self._sceneEditor.bold).pack(side=tk.LEFT)
        '''

        # Add a "File" Submenu to the editor window.
        self._fileMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Scene'), menu=self._fileMenu)
        self._fileMenu.add_command(label=_('Next'), command=self._load_next)
        self._fileMenu.add_command(label=_('Previous'), command=self._load_prev)
        self._fileMenu.add_command(label=_('Apply changes'), accelerator=KEY_APPLY_CHANGES[1], command=self._apply_changes)
        self._fileMenu.add_command(label=_('Exit'), accelerator=KEY_QUIT_PROGRAM[1], command=self.on_quit)

        # Add a "View" Submenu to the editor window.
        self._viewMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('View'), menu=self._viewMenu)
        self._viewMenu.add_command(label=COLOR_MODES[0][0], command=lambda: self._set_view_mode(mode=0))
        self._viewMenu.add_command(label=COLOR_MODES[1][0], command=lambda: self._set_view_mode(mode=1))
        self._viewMenu.add_command(label=COLOR_MODES[2][0], command=lambda: self._set_view_mode(mode=2))
        # note: this can't be done with a loop because of the "lambda" evaluation at runtime

        # Add an "Edit" Submenu to the editor window.
        self._editMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Edit'), menu=self._editMenu)
        self._editMenu.add_command(label=_('Copy'), accelerator='Ctrl-C', command=lambda: self._sceneEditor.event_generate("<<Copy>>"))
        self._editMenu.add_command(label=_('Cut'), accelerator='Ctrl-X', command=lambda: self._sceneEditor.event_generate("<<Cut>>"))
        self._editMenu.add_command(label=_('Paste'), accelerator='Ctrl-V', command=lambda: self._sceneEditor.event_generate("<<Paste>>"))
        self._editMenu.add_separator()
        self._editMenu.add_command(label=_('Split at cursor position'), accelerator=KEY_SPLIT_SCENE[1], command=self._split_scene)

        # Add a "Format" Submenu to the editor window.
        self._formatMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Format'), menu=self._formatMenu)
        self._formatMenu.add_command(label=_('Italic'), accelerator=KEY_ITALIC[1], command=self._sceneEditor.italic)
        self._formatMenu.add_command(label=_('Bold'), accelerator=KEY_BOLD[1], command=self._sceneEditor.bold)
        self._formatMenu.add_command(label=_('Plain'), accelerator=KEY_PLAIN[1], command=self._sceneEditor.plain)

        # Add a "Word count" Submenu to the editor window.
        self._wcMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Word count'), menu=self._wcMenu)
        self._wcMenu.add_command(label=_('Update'), accelerator=KEY_UPDATE_WORDCOUNT[1], command=self.show_wordcount)
        self._wcMenu.add_command(label=_('Enable live update'), command=self._live_wc_on)
        self._wcMenu.add_command(label=_('Disable live update'), command=self._live_wc_off)

        # Help
        self.helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), command=lambda: webbrowser.open(HELP_URL))

        # Event bindings.
        self.bind_class('Text', KEY_APPLY_CHANGES[0], self._apply_changes)
        self.bind_class('Text', KEY_QUIT_PROGRAM[0], self.on_quit)
        self.bind_class('Text', KEY_UPDATE_WORDCOUNT[0], self.show_wordcount)
        self.bind_class('Text', KEY_SPLIT_SCENE[0], self._split_scene)
        self.bind_class('Text', KEY_ITALIC[0], self._sceneEditor.italic)
        self.bind_class('Text', KEY_BOLD[0], self._sceneEditor.bold)
        self.bind_class('Text', KEY_PLAIN[0], self._sceneEditor.plain)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        if SceneEditor.liveWordCount:
            self._live_wc_on()
        else:
            self._wcMenu.entryconfig(_('Disable live update'), state='disabled')

        self.lift()
        self.isOpen = True

    def _load_scene(self):
        """Load the scene content into the text editor."""
        self.title(f'{self._scene.title} - {self._ui.novel.title}, {_("Scene")} ID {self._scId}')
        if self._scene.sceneContent:
            self._sceneEditor.set_text(self._scene.sceneContent)
        self._initialWc = self._sceneEditor.count_words()
        self.show_wordcount()

    def _load_next(self, event=None):

        def search_tree(parent, result, flag):
            """Search the tree for the scene parent ID after thisNode."""
            for child in self._ui.tv.tree.get_children(parent):
                if result:
                    break
                if child.startswith(self._ui.tv.SCENE_PREFIX):
                    if flag:
                        result = child
                        break
                    elif child == thisNode:
                        flag = True
                else:
                    result, flag = search_tree(child, result, flag)
            return result, flag

        if not self._apply_changes():
            return

        thisNode = f'{self._ui.tv.SCENE_PREFIX}{self._scId}'
        nextNode, __ = search_tree(self._ui.tv.NV_ROOT, None, False)
        if nextNode:
            self._ui.tv.tree.selection_set(nextNode)
            scId = nextNode[2:]
            self._scId = scId
            self._scene = self._ui.novel.scenes[scId]
            self._sceneEditor.clear()
            self._load_scene()

    def _load_prev(self, event=None):
        if not self._apply_changes():
            return

        def search_tree(parent, result, prevNode):
            """Search the tree for the scene node ID before thisNode."""
            for child in self._ui.tv.tree.get_children(parent):
                if result:
                    break
                if child.startswith(self._ui.tv.SCENE_PREFIX):
                    if child == thisNode:
                        result = prevNode
                        break
                    else:
                        prevNode = child
                else:
                    result, prevNode = search_tree(child, result, prevNode)
            return result, prevNode

        if not self._apply_changes():
            return

        thisNode = f'{self._ui.tv.SCENE_PREFIX}{self._scId}'
        prevNode, __ = search_tree(self._ui.tv.NV_ROOT, None, None)
        if prevNode:
            self._ui.tv.tree.selection_set(prevNode)
            scId = prevNode[2:]
            self._scId = scId
            self._scene = self._ui.novel.scenes[scId]
            self._sceneEditor.clear()
            self._load_scene()

    def _live_wc_on(self, event=None):
        self.bind('<KeyRelease>', self.show_wordcount)
        self._wcMenu.entryconfig(_('Enable live update'), state='disabled')
        self._wcMenu.entryconfig(_('Disable live update'), state='normal')
        self.show_wordcount()
        SceneEditor.liveWordCount = True

    def _live_wc_off(self, event=None):
        self.unbind('<KeyRelease>')
        self._wcMenu.entryconfig(_('Enable live update'), state='normal')
        self._wcMenu.entryconfig(_('Disable live update'), state='disabled')
        SceneEditor.liveWordCount = False

    def _set_view_mode(self, event=None, mode=0):
        SceneEditor.colorMode = mode
        self._set_editor_colors()

    def _set_editor_colors(self):
        self._sceneEditor['fg'] = COLOR_MODES[SceneEditor.colorMode][1]
        self._sceneEditor['bg'] = COLOR_MODES[SceneEditor.colorMode][2]
        self._sceneEditor['insertbackground'] = COLOR_MODES[SceneEditor.colorMode][1]

    def show_status(self, message=None):
        """Display a message on the status bar."""
        self._statusBar.config(text=message)

    def show_wordcount(self, event=None):
        """Display a message on the status bar."""
        wc = self._sceneEditor.count_words()
        diff = wc - self._initialWc
        self._statusBar.config(text=f'{wc} {_("words")} ({diff} {_("new")})')

    def _apply_changes(self, event=None):
        """Write the editor content to the project, if possible.
        
        On error, return False, otherwise return True. 
        """
        sceneText = self._sceneEditor.get_text()
        if sceneText or self._scene.sceneContent:
            if self._scene.sceneContent != sceneText:
                if self._ui.isLocked:
                    messagebox.showinfo(PLUGIN, _('Cannot apply scene changes, because the project is locked.'))
                    return False

                self._scene.sceneContent = sceneText
                self._ui.isModified = True
        return True

    def on_quit(self, event=None):
        """Exit the editor. Apply changes, if possible."""
        sceneText = self._sceneEditor.get_text()
        if sceneText or self._scene.sceneContent:
            if self._scene.sceneContent != sceneText:
                if self._ui.ask_yes_no(_('Apply scene changes?')):
                    if self._ui.isLocked:
                        if self._ui.ask_yes_no(_('Cannot apply scene changes, because the project is locked.\nUnlock and apply changes?')):
                            self._ui.unlock()
                            self._scene.sceneContent = sceneText
                            self._ui.isModified = True
                    else:
                        self._scene.sceneContent = sceneText
                        self._ui.isModified = True
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

    def lift(self):
        """Bring window to the foreground and set the focus to the editor box.
        
        Extends the superclass method.
        """
        super().lift()
        self._sceneEditor.focus()

    def _split_scene(self, event=None):
        """Split a scene at the cursor position."""
        if self._ui.isLocked:
            messagebox.showinfo(PLUGIN, _('Cannot split the scene, because the project is locked.'))
            return

        if not self._ui.ask_yes_no(f'{_("Move the text from the cursor position to the end into a new scene")}?'):
            return

        # Add a new scene.
        thisNode = f'{self._ui.tv.SCENE_PREFIX}{self._scId}'
        newId = self._ui.tv.add_scene(selection=thisNode)
        if newId:
            # Cut the actual scene's content from the cursor position to the end.
            newContent = self._sceneEditor.get_text(tk.INSERT, tk.END).strip(' \n')
            self._sceneEditor.delete(tk.INSERT, tk.END)
            self._apply_changes()

            # Copy the scene content to the new scene.
            self._ui.novel.scenes[newId].sceneContent = newContent

            # Append the new scene to the previous scene.
            self._ui.novel.scenes[newId].appendToPrev = True

            # Copy the scene status.
            status = self._ui.novel.scenes[self._scId].status
            self._ui.novel.scenes[newId].status = status

            # Copy the scene type.
            scType = self._ui.novel.scenes[self._scId].scType
            self._ui.novel.scenes[newId].scType = scType

            # Copy the viewpoint character.
            if self._ui.novel.scenes[self._scId].characters:
                viewpoint = self._ui.novel.scenes[self._scId].characters[0]
                self._ui.novel.scenes[newId].characters = [viewpoint]

from configparser import ConfigParser


class Configuration:
    """Application configuration, representing an INI file.

        INI file sections:
        <self._sLabel> - Strings
        <self._oLabel> - Boolean values

    Public methods:
        set(settings={}, options={}) -- set the entire configuration without writing the INI file.
        read(iniFile) -- read a configuration file.
        write(iniFile) -- save the configuration to iniFile.

    Public instance variables:    
        settings - dictionary of strings
        options - dictionary of boolean values
    """

    def __init__(self, settings={}, options={}):
        """Initalize attribute variables.

        Optional arguments:
            settings -- default settings (dictionary of strings)
            options -- default options (dictionary of boolean values)
        """
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        """Set the entire configuration without writing the INI file.

        Optional arguments:
            settings -- new settings (dictionary of strings)
            options -- new options (dictionary of boolean values)
        """
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        """Read a configuration file.
        
        Positional arguments:
            iniFile -- str: path configuration file path.
            
        Settings and options that can not be read in, remain unchanged.
        """
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        """Save the configuration to iniFile.

        Positional arguments:
            iniFile -- str: path configuration file path.
        """
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)

SETTINGS = dict(
        window_geometry='600x800',
        color_mode=0,
        color_fg_bright='white',
        color_bg_bright='black',
        color_fg_light='antique white',
        color_bg_light='black',
        color_fg_dark='light grey',
        color_bg_dark='gray20',
        font_family='Courier',
        font_size=12,
        line_spacing=6,
        paragraph_spacing=18,
        margin_x=40,
        margin_y=20,
        )
OPTIONS = dict(
        live_wordcount=False,
        )


class Plugin:
    """novelyst multi-scene "plain text" editor plugin class.
    
    Public methods:
        on_close() -- Actions to be performed when a project is closed.       
        on_quit() -- Actions to be performed when novelyst is closed.       
    """
    VERSION = '4.3.3'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A multi-scene "plain text" editor'
    URL = 'https://peter88213.github.io/novelyst_editor'

    def install(self, ui):
        """Add a submenu to the main menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui

        #--- Load configuration.
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.pywriter/novelyst/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/editor.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        # Add the "Edit" command to novelyst's "Scene" menu.
        self._ui.sceneMenu.add_separator()
        self._ui.sceneMenu.add_command(label=_('Edit'), underline=0, command=self._edit_scene)
        self._ui.tv.tree.bind('<Double-1>', self._edit_scene)
        self._ui.tv.tree.bind('<Return>', self._edit_scene)

        self.sceneEditors = {}
        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self._icon = tk.PhotoImage(file=f'{path}/icons/{ICON}.png')
        except:
            self._icon = None

        # Configure the editor box.
        SceneEditor.colorMode = int(self.kwargs['color_mode'])
        SceneEditor.liveWordCount = self.kwargs['live_wordcount']

    def _edit_scene(self, event=None):
        """Create a scene editor window with a menu bar, a text box, and a status bar."""
        try:
            nodeId = self._ui.tv.tree.selection()[0]
            if nodeId.startswith(self._ui.tv.SCENE_PREFIX):
                # A scene is selected
                if self._ui.isLocked:
                    messagebox.showinfo(PLUGIN, _('Cannot edit scenes, because the project is locked.'))
                    return

                scId = nodeId[2:]
                if scId in self.sceneEditors and self.sceneEditors[scId].isOpen:
                    self.sceneEditors[scId].lift()
                    return

                self.sceneEditors[scId] = SceneEditor(self, self._ui, scId, self.kwargs['window_geometry'], icon=self._icon)

        except IndexError:
            # Nothing selected
            pass

    def on_close(self, event=None):
        """Actions to be performed when a project is closed.
        
        Close all open scene editor windows. 
        """
        for scId in self.sceneEditors:
            if self.sceneEditors[scId].isOpen:
                self.sceneEditors[scId].on_quit()

    def on_quit(self, event=None):
        """Actions to be performed when novelyst is closed."""
        self.on_close()

        #--- Save project specific configuration
        self.kwargs['color_mode'] = SceneEditor.colorMode
        self.kwargs['live_wordcount'] = SceneEditor.liveWordCount
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

